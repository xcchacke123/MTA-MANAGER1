By minde95s
"I just edited this Hud for transparecy"

1.Introduction
2.Minimap
3.GTA V HUD 16x9 SP and MP edition
4.GTA V HUD 4x3 SP and MP edition
5.Credit:
6.Other stuff
-----------------------------

1.First of all I'm want to say sorry becouse I edited and published other mods without permission.

2.Replace all files from (To GTA3.IMG) folder to gta3.img using with imgtool or SparkCS

3.For "Transparent HUD" Copy all files from (16x9 Graphical SP or MP) folder into your GTA SA root folder.

4.For "Transparent HUD" Copy all files from (4x3 Graphical SP or MP) folder into your GTA SA root folder. 

5.Finally in45do give me permission for this mod

6.This Mod for 16x9 & 4x3 Aspect Ratio screens

If you have map glitch Rebuild gta3.img

I dont maked Police Hud for this mod

If you have problems with mods , I always
say - start from begining and find what you doing wrong.

To install this mod CLEO library required
