GTA V HUD v0.925 - "Next-Gen Edition"
-------------------------------------------------------------
Список изменений в v0.925
-Исправлен вылет при запуске игры в 16-битном видеорежиме
-Исправлен баг с радаром (Next-Gen версия)
-Добавлены параметры настройки "bOverlayColor" и "bOverlayBlur"
-Параметр "bEnableStats" теперь работает
-Другие небольшие изменения и фиксы
-------------------------------------------------------------
Installation instructions:
-------------------------------------------------------------
1) Author`s site: vk.com/dk22pac
Author: DK22Pac
Was added to the site by user: 0v3r1ord
{tag_tag} HUD
-------------------------------------------------------------
2) Copying files:
All contents of the folder "To copy to game folder" copy into the game folder confirming the replacement.

(!) If You wish to be able to remove a modification, make sure You save original copies of the replaced files safely.
-------------------------------------------------------------
This modification was downloaded from https://GameModding.com/ website
Follow us in social networks!
http://vk.com/gamemoddingcom
https://twitter.com/GameModdingNet
http://www.facebook.com/gamemodding
http://www.youtube.com/user/GameModdingPreview
