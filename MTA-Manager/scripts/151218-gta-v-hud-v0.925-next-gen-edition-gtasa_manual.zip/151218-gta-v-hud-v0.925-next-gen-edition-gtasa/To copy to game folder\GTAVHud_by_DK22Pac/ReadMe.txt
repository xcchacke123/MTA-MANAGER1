GTA V HUD by DK22Pac v0.925 ("Next-gen Edition")
Build on plugin SDK (03.01.2015)

==Installation==
Copy all files from folder "put to SA folder" into your GTA SA folder. Or if your ASI loader
supports loading from 'scripts' folder, you can put these files there.

==Addons==
Also it's offered to install additional files - radar blips and fonts from GTA V. For
more information look to the folder "add-on".

==Distribution==
You can share this file (archive) on other resources (other than fee-sharing services).
You can't use this archive's content in your mods. Ask author (DK22Pac) for more
information.

Changing and publishing modification's setting and texture files is allowed.

==Changes in version v0.925==
 -Fixed crash when running game in 16bit video mode
 -Fixed bug with radar (Next-Gen version)
 -Added settings parameters "bOverlayColor" and "bOverlayBlur"
 -Parameter "bEnableStats" is working now
 -Some minor fixes and changes

==Changes in version v0.920==
 -Changed HUD design in accordance with the Next-gen version of GTA V.
 -Improved compatibility with SA:MP
 -Added new settings in the configuration file (you can now configure such elemets as weapon
    stats window, "trip skip" dialogue)
 -Improved algorithm for calculating radar coordinates
 -Some minor fixes and changes
 -The "U" key is now used for displaying a HUD (previously used key "T").

==Changes in version v0.910==
 -Improved shaders loading
 -More improvements for SA:MP compability (fixing bugs also)
 -Fixed 'run out of ammo' crash
 -V HUD Text system  - all V HUD text now placed in one .ini file
 -New, more efficient way to calculate blip positions
 -Radar map, cop searching circle and gang areas became proportional
 -New player photo style
 -New subtitles design
 -'Trip skip' text and icon were re-designed
 -Fixed some textures
 -Some minor fixes and changes

==Changes in version v0.890==
 -Fixed problem with D3DX shaders loading
 -Added basic support for SA:MP(removed slow motion, fixed weapon selector)
 -Remade phone style
 -Added ability to show path to mission markers and objectives (GPS)
 -Fixed displaying of some in-game menus
 -Mission success/fail text with GTA V style
 -Fixed displaying of police helis on radar
 -Added alternative controls for weapon selector (doesn't work in SAMP)
 -Added ability to show additional info (money count, location, etc.)
 -Fixed ability to change radar position in settings
 -Some minor fixes and changes

==Thanks list==
Thanks to all people who waited for this mod and supported it in official forum topics:
http://gtaforums.com/topic/652697-sawip-gta5-hud-by-dk22pac
http://vol-gta.com/forum/46-2244-1
http://www.gforums.ru/topic/15614-gta5-hud-by-dk22pac
And in official DK22Pac's mods page:
http://www.vk.com/dk22pac
Thanks to AlexGT for helping with radio names list.
Thanks to BoPoH for his usual support.
Thanks to YaroslavSokol for some weapon icons.
Thanks to pluginSDK developers and GTA coders community - Deji, Wesser, Silent (SilentPL), 
Link (LINK 2012), fastman (fastman92).

Our testers:
*Old versions:
    13AG, elMarco, Oksu, Sandler, TJGM
*New versions:
    Camil1999, Crank_AG, johnny404, jose65656, Musi, R4GN0R0K

==Plugin.dll compatibility==
This plugin was built with new version of Plugin SDK, which is not compatible with plugin.dll
(which was a part of older SDK version). This means, to launch this mod, you need to delete
plugin.dll and all plugins which use it.

==Other plugins compatibility==
It's not recommended to combine this plugin with others which replace game's HUD.

==SA:MP  compatibility==
The mod is fully compatible with SA:MP. In addition, multiplayer uses its own configuration 
file - it is located in the folder "GTAVHud_by_DK22Pac\mp\".

==Requirements==
GTA SA 1.0 US version
ASI Loader
Video card with Shader Model 2.0 support. Some shaders (blur shaders) need 3.0 shader model to be
loaded. If your video card doesn't support needed shader model, the loading of a shader will
be skipped.

==Contacts==
GTAForums (ENG) http://gtaforums.com/user/394532-dk22pac/
libertycity (RUS) http://www.libertycity.ru/user/DK22Pac/
VK "DK Mods" page (RUS) http://www.vk.com/dk22pac