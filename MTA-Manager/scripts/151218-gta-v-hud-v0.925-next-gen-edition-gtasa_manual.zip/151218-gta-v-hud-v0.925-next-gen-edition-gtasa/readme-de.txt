GTA V HUD v0.925 - "Next-Gen Edition"
-------------------------------------------------------------
Список изменений в v0.925
-Исправлен вылет при запуске игры в 16-битном видеорежиме
-Исправлен баг с радаром (Next-Gen версия)
-Добавлены параметры настройки "bOverlayColor" и "bOverlayBlur"
-Параметр "bEnableStats" теперь работает
-Другие небольшие изменения и фиксы
-------------------------------------------------------------
Installation Anleitung:
-------------------------------------------------------------
1) Seite des Autors: vk.com/dk22pac
Der Autor: DK22Pac
Auf der Site vom Benutzer hinzugefuegt wurde: 0v3r1ord
{tag_tag} HUD
-------------------------------------------------------------
2) Kopieren von Dateien:
Alle Inhalte des Ordners "To copy to game folder" Kopieren Sie in den Spiel-Ordner den Ersatz bestaetigt.

(!) Wenn Sie in der Lage sein, die Aenderung zu entfernen, stellen Sie sicher, dass Sie die Original-Kopien ersetzten Dateien an einem sicheren Ort erhalten.
-------------------------------------------------------------
Diese Modifikation wurde von der Website https://GameModding.com/en/ heruntergeladen\r\nFolgen Sie uns in den sozialen Netzwerken!
http://vk.com/gamemoddingcom
https://twitter.com/GameModdingNet
http://www.facebook.com/gamemodding
http://www.youtube.com/user/GameModdingPreview
